"""Parametric field architectures for Operational Worlds.

All dimensions are expressed in millimetres. The core layer intentionally
contains no Blender dependency: it describes a rectangular field and a set of
parameterized line segments that can drive Blender, projections, fabrication
drawings, or archived research records.
"""

from __future__ import annotations

from dataclasses import dataclass
from math import cos, radians, sin

INCH_MM = 25.4

DEFAULT_FIELD_WIDTH_MM = 16.0 * INCH_MM
DEFAULT_FIELD_HEIGHT_MM = 20.0 * INCH_MM
DEFAULT_LINE_WIDTH_MM = 0.50 * INCH_MM


@dataclass(frozen=True)
class FieldLine:
    x1: float
    y1: float
    x2: float
    y2: float
    width_mm: float


@dataclass(frozen=True)
class FieldSpec:
    field_id: str
    name: str
    width_mm: float
    height_mm: float
    lines: tuple[FieldLine, ...]
    parameters: dict[str, float | str]


def _validate_field(
    width_mm: float,
    height_mm: float,
    line_width_mm: float,
) -> None:
    if width_mm <= 0:
        raise ValueError("field width must be positive")

    if height_mm <= 0:
        raise ValueError("field height must be positive")

    if line_width_mm <= 0:
        raise ValueError("line width must be positive")


def build_division_field(
    width_mm: float = DEFAULT_FIELD_WIDTH_MM,
    height_mm: float = DEFAULT_FIELD_HEIGHT_MM,
    line_width_mm: float = DEFAULT_LINE_WIDTH_MM,
    orientation: str = "VERTICAL",
    position_mm: float = 0.0,
) -> FieldSpec:
    _validate_field(
        width_mm,
        height_mm,
        line_width_mm,
    )

    orientation = orientation.upper()

    if orientation == "VERTICAL":
        if abs(position_mm) >= width_mm / 2.0:
            raise ValueError("vertical division position must remain inside field")

        lines = (
            FieldLine(
                position_mm,
                -height_mm / 2.0,
                position_mm,
                height_mm / 2.0,
                line_width_mm,
            ),
        )

    elif orientation == "HORIZONTAL":
        if abs(position_mm) >= height_mm / 2.0:
            raise ValueError("horizontal division position must remain inside field")

        lines = (
            FieldLine(
                -width_mm / 2.0,
                position_mm,
                width_mm / 2.0,
                position_mm,
                line_width_mm,
            ),
        )

    else:
        raise ValueError("orientation must be VERTICAL or HORIZONTAL")

    return FieldSpec(
        field_id="FIELD-0001",
        name="Division",
        width_mm=width_mm,
        height_mm=height_mm,
        lines=lines,
        parameters={
            "orientation": orientation,
            "position_mm": position_mm,
            "line_width_mm": line_width_mm,
        },
    )


def build_intersection_field(
    width_mm: float = DEFAULT_FIELD_WIDTH_MM,
    height_mm: float = DEFAULT_FIELD_HEIGHT_MM,
    line_width_mm: float = DEFAULT_LINE_WIDTH_MM,
    vertical_position_mm: float = 0.0,
    horizontal_position_mm: float = 0.0,
) -> FieldSpec:
    _validate_field(
        width_mm,
        height_mm,
        line_width_mm,
    )

    if abs(vertical_position_mm) >= width_mm / 2.0:
        raise ValueError("vertical line position must remain inside field")

    if abs(horizontal_position_mm) >= height_mm / 2.0:
        raise ValueError("horizontal line position must remain inside field")

    lines = (
        FieldLine(
            vertical_position_mm,
            -height_mm / 2.0,
            vertical_position_mm,
            height_mm / 2.0,
            line_width_mm,
        ),
        FieldLine(
            -width_mm / 2.0,
            horizontal_position_mm,
            width_mm / 2.0,
            horizontal_position_mm,
            line_width_mm,
        ),
    )

    return FieldSpec(
        field_id="FIELD-0002",
        name="Intersection",
        width_mm=width_mm,
        height_mm=height_mm,
        lines=lines,
        parameters={
            "vertical_position_mm": vertical_position_mm,
            "horizontal_position_mm": horizontal_position_mm,
            "line_width_mm": line_width_mm,
        },
    )


def build_bottleneck_field(
    width_mm: float = DEFAULT_FIELD_WIDTH_MM,
    height_mm: float = DEFAULT_FIELD_HEIGHT_MM,
    line_width_mm: float = DEFAULT_LINE_WIDTH_MM,
    corridor_width_mm: float = 6.0 * INCH_MM,
    throat_width_mm: float = 2.5 * INCH_MM,
    throat_y_mm: float = 0.0,
    transition_length_mm: float = 2.0 * INCH_MM,
) -> FieldSpec:
    _validate_field(
        width_mm,
        height_mm,
        line_width_mm,
    )

    if corridor_width_mm <= 0:
        raise ValueError("corridor width must be positive")

    if throat_width_mm <= 0:
        raise ValueError("throat width must be positive")

    if throat_width_mm >= corridor_width_mm:
        raise ValueError("throat width must be narrower than corridor width")

    if corridor_width_mm >= width_mm:
        raise ValueError("corridor width must fit inside field")

    if transition_length_mm <= 0:
        raise ValueError("transition length must be positive")

    half_transition = transition_length_mm / 2.0
    y_lower_transition = throat_y_mm - half_transition
    y_upper_transition = throat_y_mm + half_transition

    if y_lower_transition <= -height_mm / 2.0:
        raise ValueError("lower transition falls outside field")

    if y_upper_transition >= height_mm / 2.0:
        raise ValueError("upper transition falls outside field")

    corridor_half = corridor_width_mm / 2.0
    throat_half = throat_width_mm / 2.0
    bottom = -height_mm / 2.0
    top = height_mm / 2.0

    lines = (
        FieldLine(
            -corridor_half,
            bottom,
            -corridor_half,
            y_lower_transition,
            line_width_mm,
        ),
        FieldLine(
            -corridor_half,
            y_lower_transition,
            -throat_half,
            throat_y_mm,
            line_width_mm,
        ),
        FieldLine(
            -throat_half,
            throat_y_mm,
            -corridor_half,
            y_upper_transition,
            line_width_mm,
        ),
        FieldLine(
            -corridor_half,
            y_upper_transition,
            -corridor_half,
            top,
            line_width_mm,
        ),
        FieldLine(
            corridor_half,
            bottom,
            corridor_half,
            y_lower_transition,
            line_width_mm,
        ),
        FieldLine(
            corridor_half,
            y_lower_transition,
            throat_half,
            throat_y_mm,
            line_width_mm,
        ),
        FieldLine(
            throat_half,
            throat_y_mm,
            corridor_half,
            y_upper_transition,
            line_width_mm,
        ),
        FieldLine(
            corridor_half,
            y_upper_transition,
            corridor_half,
            top,
            line_width_mm,
        ),
    )

    return FieldSpec(
        field_id="FIELD-0003",
        name="Bottleneck",
        width_mm=width_mm,
        height_mm=height_mm,
        lines=lines,
        parameters={
            "corridor_width_mm": corridor_width_mm,
            "throat_width_mm": throat_width_mm,
            "throat_y_mm": throat_y_mm,
            "transition_length_mm": transition_length_mm,
            "line_width_mm": line_width_mm,
        },
    )


def build_divergence_field(
    width_mm: float = DEFAULT_FIELD_WIDTH_MM,
    height_mm: float = DEFAULT_FIELD_HEIGHT_MM,
    line_width_mm: float = DEFAULT_LINE_WIDTH_MM,
    split_y_mm: float = 0.0,
    stem_width_mm: float = 2.5 * INCH_MM,
    branch_angle_deg: float = 32.0,
    branch_length_mm: float = 7.0 * INCH_MM,
) -> FieldSpec:
    """Build FIELD-0004 as two parallel lower boundaries that diverge upward."""

    _validate_field(
        width_mm,
        height_mm,
        line_width_mm,
    )

    if stem_width_mm <= 0:
        raise ValueError("stem width must be positive")

    if stem_width_mm >= width_mm:
        raise ValueError("stem width must fit inside field")

    if not 1.0 <= branch_angle_deg <= 80.0:
        raise ValueError("branch angle must be between 1 and 80 degrees")

    if branch_length_mm <= 0:
        raise ValueError("branch length must be positive")

    bottom_y = -height_mm / 2.0
    top_y = height_mm / 2.0

    if not bottom_y < split_y_mm < top_y:
        raise ValueError("split position must remain inside field")

    angle = radians(branch_angle_deg)
    vertical_run = top_y - split_y_mm
    horizontal_run = sin(angle) / cos(angle) * vertical_run

    half_width = width_mm / 2.0
    half_stem = stem_width_mm / 2.0
    left_split_x = -half_stem
    right_split_x = half_stem
    left_top_x = max(
        -half_width,
        left_split_x - horizontal_run,
    )
    right_top_x = min(
        half_width,
        right_split_x + horizontal_run,
    )

    lines = (
        FieldLine(
            left_split_x,
            bottom_y,
            left_split_x,
            split_y_mm,
            line_width_mm,
        ),
        FieldLine(
            right_split_x,
            bottom_y,
            right_split_x,
            split_y_mm,
            line_width_mm,
        ),
        FieldLine(
            left_split_x,
            split_y_mm,
            left_top_x,
            top_y,
            line_width_mm,
        ),
        FieldLine(
            right_split_x,
            split_y_mm,
            right_top_x,
            top_y,
            line_width_mm,
        ),
    )

    return FieldSpec(
        field_id="FIELD-0004",
        name="Divergence",
        width_mm=width_mm,
        height_mm=height_mm,
        lines=lines,
        parameters={
            "split_y_mm": split_y_mm,
            "stem_width_mm": stem_width_mm,
            "branch_angle_deg": branch_angle_deg,
            "branch_length_mm": branch_length_mm,
            "line_width_mm": line_width_mm,
        },
    )


def build_nested_zones_field(
    *,
    width_mm: float = DEFAULT_FIELD_WIDTH_MM,
    height_mm: float = DEFAULT_FIELD_HEIGHT_MM,
    line_width_mm: float = DEFAULT_LINE_WIDTH_MM,
    outer_width_mm: float = 220.0,
    outer_height_mm: float = 310.0,
    inner_width_mm: float = 120.0,
    inner_height_mm: float = 190.0,
) -> FieldSpec:
    """Build FIELD-0005 as centered inner and outer rectangular zones."""

    _validate_field(
        width_mm,
        height_mm,
        line_width_mm,
    )

    if min(outer_width_mm, outer_height_mm, inner_width_mm, inner_height_mm) <= 0:
        raise ValueError("zone dimensions must be positive")

    if inner_width_mm >= outer_width_mm or inner_height_mm >= outer_height_mm:
        raise ValueError("inner zone must fit inside outer zone")

    if outer_width_mm >= width_mm or outer_height_mm >= height_mm:
        raise ValueError("outer zone must fit inside field")

    half_outer_w = outer_width_mm / 2.0
    half_outer_h = outer_height_mm / 2.0
    half_inner_w = inner_width_mm / 2.0
    half_inner_h = inner_height_mm / 2.0

    lines = (
        FieldLine(-half_outer_w, -half_outer_h, half_outer_w, -half_outer_h, line_width_mm),
        FieldLine(half_outer_w, -half_outer_h, half_outer_w, half_outer_h, line_width_mm),
        FieldLine(half_outer_w, half_outer_h, -half_outer_w, half_outer_h, line_width_mm),
        FieldLine(-half_outer_w, half_outer_h, -half_outer_w, -half_outer_h, line_width_mm),
        FieldLine(-half_inner_w, -half_inner_h, half_inner_w, -half_inner_h, line_width_mm),
        FieldLine(half_inner_w, -half_inner_h, half_inner_w, half_inner_h, line_width_mm),
        FieldLine(half_inner_w, half_inner_h, -half_inner_w, half_inner_h, line_width_mm),
        FieldLine(-half_inner_w, half_inner_h, -half_inner_w, -half_inner_h, line_width_mm),
    )

    return FieldSpec(
        field_id="FIELD-0005",
        name="Nested Zones",
        width_mm=width_mm,
        height_mm=height_mm,
        lines=lines,
        parameters={
            "line_width_mm": line_width_mm,
            "outer_width_mm": outer_width_mm,
            "outer_height_mm": outer_height_mm,
            "inner_width_mm": inner_width_mm,
            "inner_height_mm": inner_height_mm,
        },
    )


def build_offset_zones_field(
    *,
    width_mm: float = DEFAULT_FIELD_WIDTH_MM,
    height_mm: float = DEFAULT_FIELD_HEIGHT_MM,
    line_width_mm: float = DEFAULT_LINE_WIDTH_MM,
    zone_width_mm: float = 150.0,
    zone_height_mm: float = 230.0,
    offset_x_mm: float = 72.0,
    offset_y_mm: float = 58.0,
) -> FieldSpec:
    """Build FIELD-0006 as two equal zones displaced diagonally."""

    _validate_field(
        width_mm,
        height_mm,
        line_width_mm,
    )

    if min(zone_width_mm, zone_height_mm, offset_x_mm, offset_y_mm) <= 0:
        raise ValueError("offset zone dimensions must be positive")

    if zone_width_mm + offset_x_mm >= width_mm:
        raise ValueError("offset zones must fit within field width")

    if zone_height_mm + offset_y_mm >= height_mm:
        raise ValueError("offset zones must fit within field height")

    half_w = zone_width_mm / 2.0
    half_h = zone_height_mm / 2.0
    centers = (
        (-offset_x_mm / 2.0, -offset_y_mm / 2.0),
        (offset_x_mm / 2.0, offset_y_mm / 2.0),
    )
    lines: list[FieldLine] = []

    for cx, cy in centers:
        left = cx - half_w
        right = cx + half_w
        bottom = cy - half_h
        top = cy + half_h
        lines.extend(
            (
                FieldLine(left, bottom, right, bottom, line_width_mm),
                FieldLine(right, bottom, right, top, line_width_mm),
                FieldLine(right, top, left, top, line_width_mm),
                FieldLine(left, top, left, bottom, line_width_mm),
            )
        )

    return FieldSpec(
        field_id="FIELD-0006",
        name="Offset Zones",
        width_mm=width_mm,
        height_mm=height_mm,
        lines=tuple(lines),
        parameters={
            "line_width_mm": line_width_mm,
            "zone_width_mm": zone_width_mm,
            "zone_height_mm": zone_height_mm,
            "offset_x_mm": offset_x_mm,
            "offset_y_mm": offset_y_mm,
        },
    )


def build_terminal_target_field(
    *,
    width_mm: float = DEFAULT_FIELD_WIDTH_MM,
    height_mm: float = DEFAULT_FIELD_HEIGHT_MM,
    line_width_mm: float = DEFAULT_LINE_WIDTH_MM,
    corridor_width_mm: float = 125.0,
    terminal_y_mm: float = 125.0,
    target_width_mm: float = 185.0,
) -> FieldSpec:
    """Build FIELD-0007 as a corridor terminating at a target boundary."""

    _validate_field(
        width_mm,
        height_mm,
        line_width_mm,
    )

    if min(corridor_width_mm, target_width_mm) <= 0:
        raise ValueError("terminal target dimensions must be positive")

    if corridor_width_mm >= width_mm or target_width_mm >= width_mm:
        raise ValueError("terminal target widths must fit inside field")

    if not -height_mm / 2.0 < terminal_y_mm < height_mm / 2.0:
        raise ValueError("terminal position must remain inside field")

    half_corridor = corridor_width_mm / 2.0
    half_target = target_width_mm / 2.0
    bottom = -height_mm / 2.0

    lines = (
        FieldLine(-half_corridor, bottom, -half_corridor, terminal_y_mm, line_width_mm),
        FieldLine(half_corridor, bottom, half_corridor, terminal_y_mm, line_width_mm),
        FieldLine(-half_target, terminal_y_mm, half_target, terminal_y_mm, line_width_mm),
    )

    return FieldSpec(
        field_id="FIELD-0007",
        name="Terminal / Target",
        width_mm=width_mm,
        height_mm=height_mm,
        lines=lines,
        parameters={
            "line_width_mm": line_width_mm,
            "corridor_width_mm": corridor_width_mm,
            "terminal_y_mm": terminal_y_mm,
            "target_width_mm": target_width_mm,
        },
    )


FIELD_BUILDERS = {
    "DIVISION": build_division_field,
    "INTERSECTION": build_intersection_field,
    "BOTTLENECK": build_bottleneck_field,
    "DIVERGENCE": build_divergence_field,
    "NESTED_ZONES": build_nested_zones_field,
    "OFFSET_ZONES": build_offset_zones_field,
    "TERMINAL_TARGET": build_terminal_target_field,
}
